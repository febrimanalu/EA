﻿using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CCAR
{
    public partial class UploadCar : System.Web.UI.Page
    {
        string constr = ConfigurationManager.ConnectionStrings["dbconnection"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {

            if (!this.IsPostBack)
            {
                //Populating a DataTable from database.
                DataSet dt = this.getData();
                string iid = string.Empty;
                //Building an HTML string.
                StringBuilder html = new StringBuilder();

                //Table start.
                html.Append("<table class='table table-bordered table-striped table-hover dataTable js-exportable'>");

                //Building the Header row.
                html.Append("<thead>");
                html.Append("<tr>");
                foreach (DataColumn column in dt.Tables[0].Columns)
                {
                    if (column.ColumnName != "ID")
                    {
                        html.Append("<th>");
                        html.Append(column.ColumnName);
                        html.Append("</th>");
                    }
                }
                html.Append("</tr>");
                html.Append("</thead>");

                //Building the Data rows.
                html.Append("<tbody>");
                foreach (DataRow row in dt.Tables[0].Rows)
                {
                    iid = row["ID"].ToString();
                    html.Append("<tr>");
                    foreach (DataColumn column in dt.Tables[0].Columns)
                    {
                        if (column.ColumnName != "ID")
                        {
                            if (column.ColumnName == "FixtureSN")
                            {
                                html.Append("<td>");
                                html.Append("<a href='#detail-modal' onclick=\"DetailHistory('" + iid + "');\" class='table-action-btn h3' data-animation='fadein' data-toggle='modal' data-target='#detail-modal' data-overlayspeed='200' data-overlaycolor='#36404a'>");
                                html.Append(row[column.ColumnName]);
                                html.Append("</a></td>");
                            }
                            else
                            {
                                html.Append("<td>");
                                html.Append(row[column.ColumnName]);
                                html.Append("</td>");
                            }
                        }


                    }
                    html.Append("</tr>");

                }
                html.Append("</tbody>");
                //Table end.
                html.Append("</table>");

                //Append the HTML string to Placeholder.
                PlaceHolder1.Controls.Add(new Literal { Text = html.ToString() });

            }
        }
        protected void Upload_Click(object sender, EventArgs e)
        {
            string[] validFileTypes = { "xlsx", "xls" };
            string ext = System.IO.Path.GetExtension(FileUpload1.PostedFile.FileName);
            bool isValidFile = false;
            for (int i = 0; i < validFileTypes.Length; i++)
            {
                if (ext == "." + validFileTypes[i])
                {
                    isValidFile = true;
                    break;
                }
            }
            if (!isValidFile)
            {
                Label1.ForeColor = System.Drawing.Color.Red;

                Label1.Text = "Invalid File. Please upload a File with extension " +
                               string.Join(",", validFileTypes);

            }
            else
            {
                string excelPath = Server.MapPath("~/Files/") + Path.GetFileName(FileUpload1.PostedFile.FileName);
                FileUpload1.SaveAs(excelPath);
                string connString = ConfigurationManager.ConnectionStrings["dbconnectioniin"].ConnectionString;
                string ssqltable = "udt_ccar";
                deletetable();
                using (SqlConnection oConn = new SqlConnection(connString))
                {
                    SqlCommand sqlcmd = new SqlCommand(ssqltable, oConn);
                    oConn.Open();
                    FileInfo excelSource = new FileInfo(Path.GetFullPath(excelPath));
                    using (ExcelPackage package = new ExcelPackage(excelSource))
                    {

                        var worksheet = package.Workbook.Worksheets["Sheet1"];
                        ExcelWorksheet ws = worksheet;
                        int rowCount = ws.Dimension.Rows;
                        int ColCount = ws.Dimension.Columns;
                        for (int row = 2; row <= rowCount; row++)
                        {
                            if ((ws.Cells[row, 1].Value ?? string.Empty).ToString() == "" || (ws.Cells[row, 3].Value ?? string.Empty).ToString() == "" || (ws.Cells[row, 5].Value ?? string.Empty).ToString() == "")
                            { }
                            else
                            {
                                SqlCommand SqlCmd = new SqlCommand("INSERT INTO udt_ccar (BusinessGroup, Segment, [CAR ID], Site, PLP, Originator, [Owner], Evaluator, ProxyFor, DateInitiated, DateDue, DateClosed, Aging, GlobalCustomer, Status, Defect, ReasonLevel1, CustomerPN, CARrequest) VALUES (@BusinessGroup, @Segment, @CARID, @Site, @PLP, @Originator, @Owner, @Evaluator, @ProxyFor, @DateInitiated, @DateDue, @DateClosed, @Aging, @GlobalCustomer, @Status, @Defect, @ReasonLevel1, @CustomerPN, @CARrequest)", oConn);
                                SqlCmd.Parameters.AddWithValue("@BusinessGroup", (ws.Cells[row, 1].Value ?? string.Empty).ToString());
                                SqlCmd.Parameters.AddWithValue("@Segment", (ws.Cells[row, 2].Value ?? string.Empty).ToString());
                                SqlCmd.Parameters.AddWithValue("@CARID", (ws.Cells[row, 4].Value ?? string.Empty).ToString());
                                SqlCmd.Parameters.AddWithValue("@Site", (ws.Cells[row, 6].Value ?? string.Empty).ToString());
                                SqlCmd.Parameters.AddWithValue("@PLP", (ws.Cells[row, 7].Value ?? string.Empty).ToString());
                                SqlCmd.Parameters.AddWithValue("@Originator", (ws.Cells[row, 8].Value ?? string.Empty).ToString());
                                SqlCmd.Parameters.AddWithValue("@Owner", (ws.Cells[row, 9].Value ?? string.Empty).ToString());
                                SqlCmd.Parameters.AddWithValue("@Evaluator", (ws.Cells[row, 10].Value ?? string.Empty).ToString());
                                SqlCmd.Parameters.AddWithValue("@ProxyFor", (ws.Cells[row, 11].Value ?? string.Empty).ToString());
                                SqlCmd.Parameters.AddWithValue("@DateInitiated", (ws.Cells[row, 12].Value ?? string.Empty).ToString());
                                SqlCmd.Parameters.AddWithValue("@DateDue", (ws.Cells[row, 13].Value ?? string.Empty).ToString());
                                SqlCmd.Parameters.AddWithValue("@DateClosed", (ws.Cells[row, 14].Value ?? string.Empty).ToString());
                                SqlCmd.Parameters.AddWithValue("@Aging", (ws.Cells[row, 15].Value ?? string.Empty).ToString());
                                SqlCmd.Parameters.AddWithValue("@GlobalCustomer", (ws.Cells[row, 16].Value ?? string.Empty).ToString());
                                SqlCmd.Parameters.AddWithValue("@Status", (ws.Cells[row, 17].Value ?? string.Empty).ToString());
                                SqlCmd.Parameters.AddWithValue("@Defect", (ws.Cells[row, 18].Value ?? string.Empty).ToString());
                                SqlCmd.Parameters.AddWithValue("@ReasonLevel1", (ws.Cells[row, 19].Value ?? string.Empty).ToString());
                                SqlCmd.Parameters.AddWithValue("@CustomerPN", (ws.Cells[row, 20].Value ?? string.Empty).ToString());
                                SqlCmd.Parameters.AddWithValue("@CARrequest", (ws.Cells[row, 21].Value ?? string.Empty).ToString());

                                SqlCmd.ExecuteNonQuery();
                            }

                        }
                    }


                }
                //Label1.Text = "File uploaded successfully.";

                ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "alert('File uploaded successfully');window.location ='UploadCar.aspx';", true);
            }


        }

        private void deletetable()
        {
            SqlConnection conn = new SqlConnection(constr);
            conn.Open();
            string itmQuery = "truncate table udt_ccar";
            SqlCommand addCmd = new SqlCommand(itmQuery, conn);
            addCmd.ExecuteNonQuery();
            conn.Close();
        }
        protected void Download_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Download/Template.xlsx");
        }
        private DataSet getData()
        {
            using (SqlConnection oConn = new SqlConnection(constr))
            {
                oConn.Open();
                using (SqlCommand Sqlcmd = new SqlCommand("select ID, BusinessGroup, Segment, [CAR ID], Site, PLP, Originator, [Owner], Evaluator, ProxyFor, DateInitiated, DateDue, DateClosed, Aging, GlobalCustomer, Status, Defect, ReasonLevel1, CustomerPN, CARrequest from udt_ccar", oConn))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter(Sqlcmd))
                    {
                        using (DataSet ds = new DataSet())
                        {
                            da.Fill(ds);
                            return ds;
                        }
                    }
                }
            }
        }


    }
}