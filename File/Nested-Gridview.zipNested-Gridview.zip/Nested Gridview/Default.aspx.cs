﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class _Default : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection("Data Source=hightechnology;Integrated Security=true;Initial Catalog=session");
    protected void Page_Load(object sender, EventArgs e)
    {
            if (!IsPostBack)
            {
            BindGridview();
            }
    }
    
    protected void BindGridview()
    {
            con.Open();
            SqlCommand cmd = new SqlCommand("select deptno,dname from dept", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            con.Close();
            GridView1.DataSource = ds;
            GridView1.DataBind();

    }
    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            con.Open();
            GridView GridView2 = (GridView)e.Row.FindControl("gvnested");
            int deptno = Convert.ToInt32(e.Row.Cells[1].Text);
            SqlCommand cmd = new SqlCommand("select * from emp where deptno=" + deptno, con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            con.Close();
            GridView2.DataSource = ds;
            GridView2.DataBind();
        }
    }
}